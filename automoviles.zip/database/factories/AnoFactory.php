<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Ano;
use Faker\Generator as Faker;

$factory->define(Ano::class, function (Faker $faker) {
    return [

    ];
});
