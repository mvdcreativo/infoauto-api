<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tariff;
use Faker\Generator as Faker;

$factory->define(Tariff::class, function (Faker $faker) {
    return [
        //
    ];
});
